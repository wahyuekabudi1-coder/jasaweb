---
name: NexStack Visual Identity
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363941'
  surface-container-lowest: '#0b0e15'
  surface-container-low: '#191b23'
  surface-container: '#1d1f27'
  surface-container-high: '#272a32'
  surface-container-highest: '#32353d'
  on-surface: '#e1e2ec'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#e1e2ec'
  inverse-on-surface: '#2d3038'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#c0c1ff'
  on-secondary: '#1000a9'
  secondary-container: '#3131c0'
  on-secondary-container: '#b0b2ff'
  tertiary: '#eef7ff'
  on-tertiary: '#00354a'
  tertiary-container: '#aee0ff'
  on-tertiary-container: '#00668b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#c4e7ff'
  tertiary-fixed-dim: '#7bd0ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#10131a'
  on-background: '#e1e2ec'
  surface-variant: '#32353d'
typography:
  display:
    fontFamily: Space Grotesk
    fontSize: 4rem
    fontWeight: '700'
    lineHeight: 4.5rem
    letterSpacing: -0.04em
  display-mobile:
    fontFamily: Space Grotesk
    fontSize: 2.5rem
    fontWeight: '700'
    lineHeight: 3rem
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 3rem
    fontWeight: '600'
    lineHeight: 3.5rem
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: 0em
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0em
  label-code:
    fontFamily: JetBrains Mono
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: 1.125rem
    letterSpacing: 0.02em
  label-badge:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 1.5rem
  margin-md: 3rem
  margin-lg: 5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses high-velocity precision, architectural reliability, and forward-leaning technical mastery. Tailored for enterprise clients, venture-backed founders, and modern technology partners, the aesthetic conveys engineering rigor paired with editorial elegance.

The visual style synthesizes modern dark minimalism with high-end glassmorphic and luminous tactile elements. Interfaces live on multi-layered carbon and deep navy substrates. Interactive objects and structural boundaries are punctuated by crystalline cyan accents, refined hairline borders, and soft atmospheric backdrops that simulate low-latency, mission-critical digital craftsmanship.

## Colors

The palette operates on a calibrated dark canvas engineered to reduce optical fatigue while maintaining punchy contrast.

- **Primary (`#00F0FF` - Electric Cyan):** Used strictly for core calls-to-action, critical active states, real-time indicators, and focused accents.
- **Secondary (`#6366F1` - Electric Indigo):** Supports primary interactive elements, multi-tone gradients, and secondary accents to soften bright cyan focal points.
- **Tertiary (`#38BDF8` - Sky Plasma):** Deployed for subtle highlights, active badges, and analytical data visualizations.
- **Neutral (`#0A0D14` - Deep Carbon Canvas):** Forms the foundational background. Tiered surface elevations scale from `#0E131F` (Surface-01) to `#161D2E` (Surface-02) and `#1E2638` (Surface-03).
- **Foreground Neutral (`#F1F5F9` to `#94A3B8`):** Off-white Slate-100 handles primary readability; Slate-400 serves secondary metadata and muted supporting labels.

## Typography

The typographic hierarchy establishes clear structural authority and tech-forward readability.

- **Display & Headings (Space Grotesk):** Provides engineered structural flair with geometric quirks and tight tracking, signaling architectural confidence.
- **Body & Editorial (Hanken Grotesk):** Delivers clean neo-grotesque rhythm across continuous paragraphs, long-form project case studies, and technical overviews.
- **Code & Metadata (JetBrains Mono):** Applies tabular monospaced precision to tech stack indicators, git hashes, system status values, and metric badges.

## Layout & Spacing

This design system uses a strict 12-column fluid grid on desktop and tablet, resolving to a 4-column flow on mobile viewports.

- **Desktop (1200px+):** 12 columns, `margin-lg` (5rem) margins, and `gutter-lg` (2rem) gutters. Section verticals maintain breathing room with `space-xl` multiplications.
- **Tablet (768px - 1199px):** 8 columns, `margin-md` (3rem) margins, and `gutter` (1.5rem) gutters. Two-column cards preserve compact proportions.
- **Mobile (< 768px):** 4 columns, `margin` (1.5rem) margins, and `gutter-sm` (1rem) gutters. Complex horizontal layouts stack linearly to optimize vertical scroll rhythm.

## Elevation & Depth

Visual depth is achieved through layered glassmorphism, disciplined surface stacking, and ambient directional luminescence rather than heavy drop shadows:

- **Base Canvas:** `#0A0D14` serves as the non-reflective root plane.
- **Glassmorphic Panels:** 12px to 16px backdrop blur paired with semi-transparent fills (`rgba(14, 19, 31, 0.7)`).
- **Hairline Strokes:** Surfaces are framed by a 1px boundary using `rgba(255, 255, 255, 0.08)` or `rgba(0, 240, 255, 0.2)` on active interactive panels.
- **Luminescent Glow:** Interactive elevations utilize diffused cyan ambient shadows (`0 8px 32px -4px rgba(0, 240, 255, 0.12)`) to indicate focus and elevate key calls-to-action off the screen.

## Shapes

The design system enforces Level 2 roundedness (`rounded` = 0.5rem / 8px) across core controls and cards, striking a balance between precise machinery and modern ergonomics.

- **Interactive Controls (Inputs, Buttons):** Set at `0.5rem` (8px) for crisp handoffs.
- **Cards & Modal Surfaces (`rounded-lg`):** Styled at `1rem` (16px) to house nested components comfortably without clipping internal paddings.
- **Status Pills & Micro Badges:** Fully circular or pill-shaped (`rounded-full`) to contrast against rectilinear card structures.

## Components

### Buttons
- **Primary:** High-contrast Electric Cyan background (`#00F0FF`), rich dark-slate text (`#0A0D14`), `JetBrains Mono` or semi-bold `Space Grotesk` uppercase label. Hover triggers a radiant outer glow (`box-shadow: 0 0 20px rgba(0, 240, 255, 0.35)`).
- **Secondary:** Semi-transparent glass backing (`rgba(255, 255, 255, 0.04)`), 1px border (`rgba(255, 255, 255, 0.12)`), Slate-100 text. Hover transitions border color to Electric Indigo (`#6366F1`).
- **Ghost:** Text-only in Slate-300 with an inline chevron; hover state transitions text to Electric Cyan with subtle underline tracking.

### Tech Badges & Chips
- Compact pills rendered with `JetBrains Mono` at `label-badge` scale.
- Translucent dark fills (`rgba(0, 240, 255, 0.06)`) framed by a 1px border (`rgba(0, 240, 255, 0.2)`).
- Optional leading active-state dot (3px pulsing cyan indicator for live production services or supported stacks).

### Cards
- Framed with 1px border (`rgba(255, 255, 255, 0.07)`), glass fill, and internal padding (`space-lg`).
- Subtle linear gradient overlays (`linear-gradient(135deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0) 100%)`).
- Hover shifts the border to subtle cyan/indigo and translates the surface -2px vertically.

### Input Fields
- Deep carbon background (`#0E131F`), 1px muted border (`rgba(255, 255, 255, 0.1)`), and text in Slate-100.
- Focused state applies an Electric Cyan border (`#00F0FF`) with an ambient outer glow (`box-shadow: 0 0 0 3px rgba(0, 240, 255, 0.15)`).
- Monospaced helper text positioned directly below the field.

### Selection Controls (Checkboxes & Radios)
- Custom square (`0.5rem` radius) or circle containers with deep carbon base.
- Checked state reveals a solid Electric Cyan fill with dark contrasting checkmark iconography.

### Code Blocks & Architecture Snippets
- Dedicated container using Surface-01 (`#0E131F`) with hairline borders and an integrated tab bar for multi-file code execution displays.
- Syntax highlighting uses the brand's primary and secondary accents against muted slate code text.